﻿document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('supplierForm').addEventListener('submit', async function (event) {
        event.preventDefault(); // Prevent default form submission

        var isValid = true;

        // Get form elements
        var supplierName = document.getElementById('supplierName');
        var supplierContact = document.getElementById('supplierContact');
        var companyName = document.getElementById('companyName');
        var companyAddress = document.getElementById('companyAddress');
        var supplierEmail = document.getElementById('supplierEmail');
        var supplierPassword = document.getElementById('supplierPassword');

        // Clear previous error messages
        document.getElementById('supplierNameError').textContent = '';
        document.getElementById('supplierContactError').textContent = '';
        document.getElementById('companyNameError').textContent = '';
        document.getElementById('companyAddressError').textContent = '';
        document.getElementById('supplierEmailError').textContent = '';
        document.getElementById('supplierPasswordError').textContent = '';

        // Validate SupplierName
        if (!/^[A-Za-z\s]{1,20}$/.test(supplierName.value)) {
            document.getElementById('supplierNameError').textContent = 'Name should contain only letters and spaces, and be less than 20 characters long.';
            isValid = false;
        }

        // Validate SupplierContact
        if (supplierContact.value.length !== 10 || isNaN(supplierContact.value)) {
            document.getElementById('supplierContactError').innerText = "Supplier Contact must be a 10-digit number.";
            isValid = false;
        }

        // Validate CompanyName
        if (companyName.value.trim() === '') {
            document.getElementById('companyNameError').textContent = 'Company Name is required.';
            isValid = false;
        }

        // Validate CompanyAddress
        if (companyAddress.value.trim() === '') {
            document.getElementById('companyAddressError').textContent = 'Company Address is required.';
            isValid = false;
        }

        // Validate SupplierEmail
        if (!/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(supplierEmail.value)) {
            document.getElementById('supplierEmailError').textContent = 'Please enter a valid email address.';
            isValid = false;
        }

        // Validate SupplierPassword
        if (supplierPassword.value.trim() === '') {
            document.getElementById('supplierPasswordError').textContent = 'Password is required.';
            isValid = false;
        }

        // If any validation fails, stop the submission
        if (!isValid) {
            return;
        }

        // If client-side validation passes, send the form data using fetch
        var formData = {
            SupplierName: supplierName.value,
            SupplierContact: supplierContact.value,
            CompanyName: companyName.value,
            CompanyAddress: companyAddress.value,
            SupplierEmail: supplierEmail.value,
            SupplierPassword: supplierPassword.value
        };

        try {
            const response = await fetch('/Login/SupplierRegister', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                // If the response is OK, redirect to the login page or success page
                window.location.href = "/Login/LoginPage";
            } else {
                // If there is an error, check the response content
                const errorMessage = await response.text();

                // Check for specific error (like email already taken)
                if (errorMessage.includes("Email is already taken")) {
                    document.getElementById('supplierEmailError').textContent = errorMessage;
                } else {
                    // Handle other types of errors if necessary
                    alert('An error occurred: ' + errorMessage);
                }
            }
        } catch (error) {
            console.error('Error submitting the form:', error);
            alert('An unexpected error occurred.');
        }
    });
});
