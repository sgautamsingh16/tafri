﻿namespace Phase4.Models
{
    public class RazorpaySettings
    {
        public string Key { get; set; }
        public string Secret { get; set; }
    }
}
