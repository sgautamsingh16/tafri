﻿using System.ComponentModel.DataAnnotations;

namespace Phase4.Models
{
    public class PriceDTO
    {
        [Key]
        public int AdminPrice { get; set; }
        public int PackagePrice { get; set; }
    }
}
