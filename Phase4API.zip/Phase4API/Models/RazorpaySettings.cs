﻿namespace Phase4API.Models
{
    public class RazorpaySettings
    {
        public string Key { get; set; }
        public string Secret { get; set; }
    }
}
