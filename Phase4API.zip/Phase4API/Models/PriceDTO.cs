﻿using System.ComponentModel.DataAnnotations;

namespace Phase4API.Models
{
    public class PriceDTO
    {
        [Key]
        public int AdminPrice { get; set; }
        public int PackagePrice { get; set; }
    }
}
